# Otto Debug Extension

This repository provides debug and tracing commands for Otto workflows.

All command behavior is internal and routed through the Otto Command Service Layer.

## Responsibilities
- Register internal debug command contracts through the command-service layer.
- Emit clean user-facing summaries and detailed trace logs.
- Capture command and API trace events.
- Generate lightweight runtime snapshots.
- Maintain last-run debug reports on disk.

## Command Contracts
- `debug.trace.command`
- `debug.trace.api`
- `debug.snapshot.system`
- `debug.report.last-run`

## Repository Layout
- `src/debug-core.ts`: TypeScript source for tracing and snapshot behavior.
- `src/debug-commands.ts`: Internal in-process command registration.
- `src/debug-runtime.mjs`: Runtime-safe bridge used by command-service handlers.
- `manifests/extension.json`: Extension metadata consumed by Otto extension registry.
- `tests/*.test.ts`: Node test coverage for trace and snapshot behaviors.

## How It Wires Into Otto
1. Register command schemas in `otto-command-service/src/schemas`.
2. Register command handlers in `otto-command-service/src/handlers`.
3. Point handlers to `src/debug-runtime.mjs` in this repo.
4. Route runtime/CLI/API workflows through command-service execution so traces are centralized.

## Integrations
- Uses `file.rotate.logs` for debug log maintenance.
- Attempts structured logger handoff through `logging.write.structured` if available.
- Mirrors API command traces for API extension consumers.

## Integration Points
- Command executor emits `debug.trace.command` for non-debug routed commands.
- Display runtime emits `debug.trace.api` for external endpoint flows.
- CLI high-level commands (`otto debug last`, `otto debug trace`, `otto debug snapshot`) route to this extension through command-service schemas.

## Local Development
1. Install dependencies: `pnpm --filter otto-debug-extension install`
2. Run tests: `pnpm --filter otto-debug-extension test`
3. Run typecheck: `pnpm --filter otto-debug-extension typecheck`

## Design Constraints
- Never expose API routes or CLI argument parsing in this repo.
- Keep user-facing summaries concise while preserving verbose trace details when requested.
- Keep trace writes resilient and non-blocking for core command execution.

## Validation
- `npm run typecheck`
