import { commandService } from "./command-service.js";
import {
  reportLastRun,
  snapshotSystem,
  traceApi,
  traceCommand,
  type DebugReportLastRunOutput,
  type DebugSnapshotSystemInput,
  type DebugTraceApiInput,
  type DebugTraceCommandInput
} from "./debug-core.js";

export const DEBUG_TRACE_COMMAND_COMMAND_ID = "debug.trace.command";
export const DEBUG_TRACE_API_COMMAND_ID = "debug.trace.api";
export const DEBUG_SNAPSHOT_SYSTEM_COMMAND_ID = "debug.snapshot.system";
export const DEBUG_REPORT_LAST_RUN_COMMAND_ID = "debug.report.last-run";

commandService.register<DebugTraceCommandInput, { ok: boolean; summary: string }>(
  DEBUG_TRACE_COMMAND_COMMAND_ID,
  async (input) => traceCommand(input)
);
commandService.register<DebugTraceApiInput, { ok: boolean; summary: string }>(DEBUG_TRACE_API_COMMAND_ID, async (input) =>
  traceApi(input)
);
commandService.register<DebugSnapshotSystemInput, Record<string, unknown>>(DEBUG_SNAPSHOT_SYSTEM_COMMAND_ID, async (input) =>
  snapshotSystem(input)
);
commandService.register<undefined, DebugReportLastRunOutput>(DEBUG_REPORT_LAST_RUN_COMMAND_ID, async () => reportLastRun());

export async function executeDebugCommand<TInput, TOutput>(commandName: string, input: TInput): Promise<TOutput> {
  return commandService.run<TInput, TOutput>(commandName, input);
}
