import os from "node:os";
import path from "node:path";

import { promises as fs } from "node:fs";
import { executeFileCommand } from "../../otto-file-extension/src/file-commands.js";

const DEBUG_LOG_ROOT = path.resolve(process.cwd(), "logs", "debug");
const TRACE_LOG_FILE = path.join(DEBUG_LOG_ROOT, "trace.log");
const LAST_RUN_FILE = path.join(DEBUG_LOG_ROOT, "last-run.json");

export interface DebugTraceCommandInput {
  command: string;
  payload?: unknown;
  status?: "start" | "ok" | "error";
  details?: string;
  verbose?: boolean;
}

export interface DebugTraceApiInput {
  method: string;
  route: string;
  statusCode?: number;
  details?: string;
  verbose?: boolean;
}

export interface DebugSnapshotSystemInput {
  includeMemory?: boolean;
  includeEnv?: boolean;
}

export interface DebugReportLastRunOutput {
  generatedAt: string;
  summary: string;
  lastRun: Record<string, unknown> | null;
}

interface DebugEntry {
  at: string;
  type: "command" | "api" | "snapshot";
  data: Record<string, unknown>;
}

async function ensureDebugRoot(): Promise<void> {
  await fs.mkdir(DEBUG_LOG_ROOT, { recursive: true });
}

async function appendTrace(entry: DebugEntry): Promise<void> {
  await ensureDebugRoot();
  await fs.appendFile(TRACE_LOG_FILE, `${JSON.stringify(entry)}\n`, "utf8");

  try {
    await executeFileCommand("file.rotate.logs", {
      directory: DEBUG_LOG_ROOT,
      maxFiles: 12,
      maxBytes: 2_000_000,
      activeLogFile: TRACE_LOG_FILE
    });
  } catch {
    // Keep tracing robust if the file extension command bridge is unavailable.
  }
}

async function writeLastRun(data: Record<string, unknown>): Promise<void> {
  await ensureDebugRoot();
  await fs.writeFile(LAST_RUN_FILE, `${JSON.stringify(data, null, 2)}\n`, "utf8");
}

async function readLastRun(): Promise<Record<string, unknown> | null> {
  try {
    const content = await fs.readFile(LAST_RUN_FILE, "utf8");
    return JSON.parse(content) as Record<string, unknown>;
  } catch {
    return null;
  }
}

async function writeStructuredLog(entry: DebugEntry): Promise<void> {
  try {
    const modulePath = path.resolve(process.cwd(), "../otto-logging-extension/src/logging-core.js");
    const logger = await import(modulePath);
    if (typeof logger.writeStructuredLog === "function") {
      await logger.writeStructuredLog(entry);
      return;
    }
  } catch {
    // Fallback to file trace log when logging extension is unavailable.
  }

  await appendTrace(entry);
}

export async function traceCommand(input: DebugTraceCommandInput): Promise<{ ok: boolean; summary: string }> {
  const entry: DebugEntry = {
    at: new Date().toISOString(),
    type: "command",
    data: {
      command: input.command,
      status: input.status ?? "ok",
      payload: input.verbose ? input.payload : undefined,
      details: input.details ?? null
    }
  };

  await writeStructuredLog(entry);
  await writeLastRun({ ...entry });

  return {
    ok: true,
    summary: `Command ${input.command} traced with status ${input.status ?? "ok"}.`
  };
}

export async function traceApi(input: DebugTraceApiInput): Promise<{ ok: boolean; summary: string }> {
  const entry: DebugEntry = {
    at: new Date().toISOString(),
    type: "api",
    data: {
      method: input.method,
      route: input.route,
      statusCode: input.statusCode ?? 0,
      details: input.details ?? null
    }
  };

  await writeStructuredLog(entry);
  await writeLastRun({ ...entry });

  return {
    ok: true,
    summary: `${input.method.toUpperCase()} ${input.route} traced.`
  };
}

export async function snapshotSystem(input: DebugSnapshotSystemInput = {}): Promise<Record<string, unknown>> {
  const snapshot = {
    at: new Date().toISOString(),
    hostname: os.hostname(),
    platform: os.platform(),
    release: os.release(),
    uptimeSeconds: os.uptime(),
    loadAverage: os.loadavg(),
    cwd: process.cwd(),
    nodeVersion: process.version,
    memory: input.includeMemory ? process.memoryUsage() : undefined,
    env: input.includeEnv ? { OTTO_API_BASE: process.env.OTTO_API_BASE ?? null } : undefined
  };

  await writeStructuredLog({ at: snapshot.at, type: "snapshot", data: snapshot as Record<string, unknown> });
  await writeLastRun({ type: "snapshot", ...snapshot });

  return snapshot;
}

export async function reportLastRun(): Promise<DebugReportLastRunOutput> {
  const lastRun = await readLastRun();
  if (!lastRun) {
    return {
      generatedAt: new Date().toISOString(),
      summary: "No debug run has been recorded yet.",
      lastRun: null
    };
  }

  const label = typeof lastRun.type === "string" ? lastRun.type : "debug";
  return {
    generatedAt: new Date().toISOString(),
    summary: `Last debug record type: ${label}.`,
    lastRun
  };
}
