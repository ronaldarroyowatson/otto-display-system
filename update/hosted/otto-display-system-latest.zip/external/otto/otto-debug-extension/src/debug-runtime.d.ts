export function executeDebugCommand(commandName: string, input?: Record<string, unknown>): Promise<any>;
