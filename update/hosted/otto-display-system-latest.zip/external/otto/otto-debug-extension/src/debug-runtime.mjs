import fs from "node:fs/promises";
import os from "node:os";
import path from "node:path";

import { executeFileCommand } from "../../otto-file-extension/src/file-runtime.mjs";

const DEBUG_LOG_ROOT = path.resolve(process.cwd(), "logs", "debug");
const TRACE_LOG_FILE = path.join(DEBUG_LOG_ROOT, "trace.log");
const LAST_RUN_FILE = path.join(DEBUG_LOG_ROOT, "last-run.json");

async function ensureDebugRoot() {
  await fs.mkdir(DEBUG_LOG_ROOT, { recursive: true });
}

async function appendTrace(entry) {
  await ensureDebugRoot();
  await fs.appendFile(TRACE_LOG_FILE, `${JSON.stringify(entry)}\n`, "utf8");

  try {
    await executeFileCommand("file.rotate.logs", {
      directory: DEBUG_LOG_ROOT,
      maxFiles: 12,
      maxBytes: 2000000,
      activeLogFile: TRACE_LOG_FILE
    });
  } catch {
    // Keep tracing resilient when rotation cannot run.
  }
}

async function writeLastRun(data) {
  await ensureDebugRoot();
  await fs.writeFile(LAST_RUN_FILE, `${JSON.stringify(data, null, 2)}\n`, "utf8");
}

async function readLastRun() {
  try {
    const content = await fs.readFile(LAST_RUN_FILE, "utf8");
    return JSON.parse(content);
  } catch {
    return null;
  }
}

async function traceCommand(input) {
  const entry = {
    at: new Date().toISOString(),
    type: "command",
    data: {
      command: input.command,
      status: input.status ?? "ok",
      payload: input.verbose ? input.payload : undefined,
      details: input.details ?? null
    }
  };

  await appendTrace(entry);
  await writeLastRun(entry);
  return { ok: true, summary: `Command ${input.command} traced with status ${input.status ?? "ok"}.` };
}

async function traceApi(input) {
  const entry = {
    at: new Date().toISOString(),
    type: "api",
    data: {
      method: input.method,
      route: input.route,
      statusCode: input.statusCode ?? 0,
      details: input.details ?? null
    }
  };

  await appendTrace(entry);
  await writeLastRun(entry);
  return { ok: true, summary: `${input.method.toUpperCase()} ${input.route} traced.` };
}

async function snapshotSystem(input = {}) {
  const snapshot = {
    at: new Date().toISOString(),
    hostname: os.hostname(),
    platform: os.platform(),
    release: os.release(),
    uptimeSeconds: os.uptime(),
    loadAverage: os.loadavg(),
    cwd: process.cwd(),
    nodeVersion: process.version,
    memory: input.includeMemory ? process.memoryUsage() : undefined,
    env: input.includeEnv ? { OTTO_API_BASE: process.env.OTTO_API_BASE ?? null } : undefined
  };

  await appendTrace({ at: snapshot.at, type: "snapshot", data: snapshot });
  await writeLastRun({ type: "snapshot", ...snapshot });
  return snapshot;
}

async function reportLastRun() {
  const lastRun = await readLastRun();
  if (!lastRun) {
    return {
      generatedAt: new Date().toISOString(),
      summary: "No debug run has been recorded yet.",
      lastRun: null
    };
  }

  const label = typeof lastRun.type === "string" ? lastRun.type : "debug";
  return {
    generatedAt: new Date().toISOString(),
    summary: `Last debug record type: ${label}.`,
    lastRun
  };
}

export async function executeDebugCommand(commandName, input = {}) {
  switch (commandName) {
    case "debug.trace.command":
      return traceCommand(input);
    case "debug.trace.api":
      return traceApi(input);
    case "debug.snapshot.system":
      return snapshotSystem(input);
    case "debug.report.last-run":
      return reportLastRun();
    default:
      throw new Error(`Unknown debug command: ${commandName}`);
  }
}
