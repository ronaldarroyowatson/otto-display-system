import assert from "node:assert/strict";
import { mkdtemp, rm } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import test from "node:test";

test("debug.trace.command writes summary", async () => {
  const { executeDebugCommand } = await import("../src/debug-runtime.mjs");
  const tempRoot = await mkdtemp(path.join(os.tmpdir(), "otto-debug-trace-"));
  const previousCwd = process.cwd();

  try {
    process.chdir(tempRoot);

    const result = await executeDebugCommand("debug.trace.command", {
      command: "display.current",
      status: "ok",
      details: "test"
    });

    assert.equal(result.ok, true);
    assert.match(result.summary, /display.current/);
  } finally {
    process.chdir(previousCwd);
    await rm(tempRoot, { recursive: true, force: true });
  }
});

test("debug.trace.api writes summary", async () => {
  const { executeDebugCommand } = await import("../src/debug-runtime.mjs");
  const tempRoot = await mkdtemp(path.join(os.tmpdir(), "otto-debug-api-"));
  const previousCwd = process.cwd();

  try {
    process.chdir(tempRoot);

    const result = await executeDebugCommand("debug.trace.api", {
      method: "GET",
      route: "/health",
      statusCode: 200
    });

    assert.equal(result.ok, true);
    assert.match(result.summary, /GET/);
  } finally {
    process.chdir(previousCwd);
    await rm(tempRoot, { recursive: true, force: true });
  }
});

test("debug.snapshot.system returns runtime metadata", async () => {
  const { executeDebugCommand } = await import("../src/debug-runtime.mjs");
  const tempRoot = await mkdtemp(path.join(os.tmpdir(), "otto-debug-snapshot-"));
  const previousCwd = process.cwd();

  try {
    process.chdir(tempRoot);

    const result = await executeDebugCommand("debug.snapshot.system", {
      includeMemory: true,
      includeEnv: true
    });

    assert.equal(typeof result.hostname, "string");
    assert.equal(typeof result.nodeVersion, "string");
    assert.equal(typeof result.memory, "object");
  } finally {
    process.chdir(previousCwd);
    await rm(tempRoot, { recursive: true, force: true });
  }
});

test("debug.report.last-run returns most recent write", async () => {
  const { executeDebugCommand } = await import("../src/debug-runtime.mjs");
  const tempRoot = await mkdtemp(path.join(os.tmpdir(), "otto-debug-report-"));
  const previousCwd = process.cwd();

  try {
    process.chdir(tempRoot);
    await executeDebugCommand("debug.trace.command", {
      command: "calendar.refresh",
      status: "ok"
    });

    const report = await executeDebugCommand("debug.report.last-run", {});
    assert.equal(typeof report.generatedAt, "string");
    assert.equal(report.lastRun?.type, "command");
  } finally {
    process.chdir(previousCwd);
    await rm(tempRoot, { recursive: true, force: true });
  }
});
