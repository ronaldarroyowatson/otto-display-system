# Otto Extensions

This repository is the root coordination layer for the Otto extension ecosystem.

## Purpose

- Global instruction anchor for extension agents.
- Registry of extension repositories and manifests.
- MemPalace room mapping and initial generation metadata.
- Home for extension-agent role files.

## Repositories

- `otto-extensions/otto-extensions`: ecosystem root and registry.
- `otto-extensions/otto-cli-extension`: command-service-driven CLI generation metadata.
- `otto-extensions/otto-api-extension`: command-service-driven API generation metadata.
- `otto-extensions/otto-auth-extension`: payload-selected auth provider generation metadata.
- `otto-extensions/otto-data-extension`: blob transfer, ZIP packaging, and compression helpers.

## Root Layout

```text
otto-extensions/
├── copilot-instructions.md
├── agents/
│   ├── OttoCLIExtensionAgent.md
│   ├── OttoAPIExtensionAgent.md
│   └── OttoDataExtensionAgent.md
├── registry/
│   └── extension-registry.json
├── mempalace/
│   ├── rooms.json
│   ├── cli-command-index.json
│   ├── cli-generation-history.json
│   ├── cli-rescan-events.json
│   ├── api-endpoint-index.json
│   ├── api-generation-history.json
│   ├── api-rescan-events.json
│   ├── auth-provider-index.json
│   ├── auth-generation-history.json
│   ├── auth-rescan-events.json
│   ├── data-blob-index.json
│   ├── data-generation-history.json
│   └── data-rescan-events.json
└── modules/
```

## Generation Flow

1. Extension generators scan their configured source roots.
2. CLI, API, or auth artifacts are regenerated from discovered command metadata.
3. Manual rescan command execution writes metadata snapshots to MemPalace.
4. Automatic rescans are triggered by `OttoUpdateAgent` after updates.

## GitOps Sync

- Run `node scripts/gitops-sync.mjs` from the root repository to refresh GitOps metadata in `mempalace/`.
- This script validates required root/CLI/API scaffolding and then rewrites:
  - `mempalace/repo-sync-index.json`
  - `mempalace/repo-commit-metadata.json`
  - `mempalace/repo-remote-urls.json`
  - `mempalace/repo-version-metadata.json`
  - `mempalace/extension-registry-metadata.json`

## Notes

- Generators consume command definitions and do not duplicate command business logic.
- If the command-service scan directory is empty or missing, generators emit warnings and keep tracer-bullet behavior.
