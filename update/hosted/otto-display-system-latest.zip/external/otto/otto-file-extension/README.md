# Otto File Extension

This repository provides the Otto file extension for storage checks, install registry metadata, safe file operations, and log rotation helpers.

All command behavior is internal and routed through the Otto Command Service Layer.

## Responsibilities
- Register internal file commands through the command-service layer.
- Check storage capacity before install/update/log workflows.
- Persist install footprint metadata (path, size, version, timestamp).
- Provide safe delete and move helpers for managed roots.
- Rotate log files for logging and debug workflows.

## Command Contracts
- `file.check.space`
- `file.list.installs`
- `file.get.install.info`
- `file.delete.path`
- `file.rotate.logs`

## Repository Layout
- `src/file-core.ts`: TypeScript source for file/storage domain logic.
- `src/file-commands.ts`: Internal in-process command registration.
- `src/file-runtime.mjs`: Runtime-safe bridge used by command-service handlers.
- `manifests/extension.json`: Extension metadata consumed by Otto extension registry.
- `tests/*.test.ts`: Node test coverage for command behavior.

## How It Wires Into Otto
1. Register command schemas in `otto-command-service/src/schemas`.
2. Register command handlers in `otto-command-service/src/handlers`.
3. Point handlers to `src/file-runtime.mjs` in this repo.
4. Reference commands from consumers (display runtime, install/update scripts) through routed command execution only.

## Integration Points
- Display runtime calls `file.rotate.logs` during startup log maintenance.
- Installer and updater scripts call `file.check.space` before package extraction.
- Debug extension calls `file.rotate.logs` for trace log retention.

## Local Development
1. Install dependencies: `pnpm --filter otto-file-extension install`
2. Run tests: `pnpm --filter otto-file-extension test`
3. Run typecheck: `pnpm --filter otto-file-extension typecheck`

## Design Constraints
- Never expose API routes or CLI argument parsing in this repo.
- Keep payload contracts deterministic and schema-friendly.
- Prefer safe path guards for destructive file operations.

## Validation
- `npm run typecheck`
