import {
  checkSpace,
  deletePath,
  getInstallInfo,
  listInstalls,
  rotateLogs,
  type DeletePathInput,
  type FileCheckSpaceInput,
  type FileCheckSpaceOutput,
  type GetInstallInfoInput,
  type InstallRegistryEntry,
  type ListInstallsOutput,
  type RotateLogsInput,
  type RotateLogsOutput
} from "./file-core.js";
import { commandService } from "./command-service.js";

export const FILE_CHECK_SPACE_COMMAND_ID = "file.check.space";
export const FILE_LIST_INSTALLS_COMMAND_ID = "file.list.installs";
export const FILE_GET_INSTALL_INFO_COMMAND_ID = "file.get.install.info";
export const FILE_DELETE_PATH_COMMAND_ID = "file.delete.path";
export const FILE_ROTATE_LOGS_COMMAND_ID = "file.rotate.logs";

commandService.register<FileCheckSpaceInput, FileCheckSpaceOutput>(FILE_CHECK_SPACE_COMMAND_ID, async (input) =>
  checkSpace(input)
);
commandService.register<undefined, ListInstallsOutput>(FILE_LIST_INSTALLS_COMMAND_ID, async () => listInstalls());
commandService.register<GetInstallInfoInput, InstallRegistryEntry | null>(FILE_GET_INSTALL_INFO_COMMAND_ID, async (input) =>
  getInstallInfo(input)
);
commandService.register<DeletePathInput, { ok: boolean; deletedPath: string }>(FILE_DELETE_PATH_COMMAND_ID, async (input) =>
  deletePath(input)
);
commandService.register<RotateLogsInput, RotateLogsOutput>(FILE_ROTATE_LOGS_COMMAND_ID, async (input) => rotateLogs(input));

export async function executeFileCommand<TInput, TOutput>(commandName: string, input: TInput): Promise<TOutput> {
  return commandService.run<TInput, TOutput>(commandName, input);
}
