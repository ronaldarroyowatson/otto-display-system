import { promises as fs } from "node:fs";
import path from "node:path";

export interface FileCheckSpaceInput {
  targetPath: string;
  minBytes: number;
}

export interface FileCheckSpaceOutput {
  ok: boolean;
  targetPath: string;
  minBytes: number;
  availableBytes: number;
}

export interface InstallRegistryEntry {
  id: string;
  installPath: string;
  version: string;
  sizeBytes: number;
  updatedAt: string;
}

export interface ListInstallsOutput {
  registryPath: string;
  installs: InstallRegistryEntry[];
}

export interface GetInstallInfoInput {
  id: string;
}

export interface DeletePathInput {
  targetPath: string;
  recursive?: boolean;
  force?: boolean;
}

export interface RotateLogsInput {
  directory: string;
  maxFiles: number;
  maxBytes: number;
  activeLogFile?: string;
}

export interface RotateLogsOutput {
  directory: string;
  rotated: string[];
  removed: string[];
}

const DEFAULT_REGISTRY_PATH = path.join("manifests", "install-registry.json");

function repoRoot(root?: string): string {
  return root ? path.resolve(root) : process.cwd();
}

function registryPath(root?: string): string {
  return path.join(repoRoot(root), DEFAULT_REGISTRY_PATH);
}

async function pathExists(targetPath: string): Promise<boolean> {
  try {
    await fs.access(targetPath);
    return true;
  } catch {
    return false;
  }
}

async function readInstallRegistry(root?: string): Promise<InstallRegistryEntry[]> {
  const filePath = registryPath(root);
  if (!(await pathExists(filePath))) {
    return [];
  }

  const content = await fs.readFile(filePath, "utf8");
  const parsed = JSON.parse(content) as unknown;
  if (!Array.isArray(parsed)) {
    return [];
  }

  return parsed as InstallRegistryEntry[];
}

async function writeInstallRegistry(entries: InstallRegistryEntry[], root?: string): Promise<void> {
  const filePath = registryPath(root);
  await fs.mkdir(path.dirname(filePath), { recursive: true });
  await fs.writeFile(filePath, `${JSON.stringify(entries, null, 2)}\n`, "utf8");
}

export async function checkSpace(input: FileCheckSpaceInput): Promise<FileCheckSpaceOutput> {
  const stats = await fs.statfs(path.resolve(input.targetPath));
  const availableBytes = Number(stats.bavail) * Number(stats.bsize);

  return {
    ok: availableBytes >= input.minBytes,
    targetPath: path.resolve(input.targetPath),
    minBytes: input.minBytes,
    availableBytes
  };
}

export async function listInstalls(root?: string): Promise<ListInstallsOutput> {
  const installs = await readInstallRegistry(root);
  return {
    registryPath: registryPath(root),
    installs: installs.sort((a, b) => b.updatedAt.localeCompare(a.updatedAt))
  };
}

export async function getInstallInfo(input: GetInstallInfoInput, root?: string): Promise<InstallRegistryEntry | null> {
  const installs = await readInstallRegistry(root);
  return installs.find((entry) => entry.id === input.id) ?? null;
}

export async function registerInstall(entry: InstallRegistryEntry, root?: string): Promise<InstallRegistryEntry> {
  const installs = await readInstallRegistry(root);
  const next = installs.filter((existing) => existing.id !== entry.id);
  next.push(entry);
  await writeInstallRegistry(next, root);
  return entry;
}

function assertSafeTarget(targetPath: string): void {
  const resolved = path.resolve(targetPath);
  const parsed = path.parse(resolved);
  if (resolved === parsed.root) {
    throw new Error(`Refusing to operate on filesystem root: ${resolved}`);
  }
}

export async function safeCreateFile(targetPath: string, contents: string): Promise<string> {
  assertSafeTarget(targetPath);
  const resolved = path.resolve(targetPath);
  await fs.mkdir(path.dirname(resolved), { recursive: true });
  await fs.writeFile(resolved, contents, "utf8");
  return resolved;
}

export async function safeMovePath(fromPath: string, toPath: string): Promise<{ fromPath: string; toPath: string }> {
  assertSafeTarget(fromPath);
  assertSafeTarget(toPath);
  const resolvedFrom = path.resolve(fromPath);
  const resolvedTo = path.resolve(toPath);
  await fs.mkdir(path.dirname(resolvedTo), { recursive: true });
  await fs.rename(resolvedFrom, resolvedTo);
  return { fromPath: resolvedFrom, toPath: resolvedTo };
}

export async function deletePath(input: DeletePathInput): Promise<{ ok: boolean; deletedPath: string }> {
  assertSafeTarget(input.targetPath);
  const deletedPath = path.resolve(input.targetPath);
  await fs.rm(deletedPath, {
    recursive: input.recursive ?? true,
    force: input.force ?? false
  });

  return { ok: true, deletedPath };
}

export async function rotateLogs(input: RotateLogsInput): Promise<RotateLogsOutput> {
  const directory = path.resolve(input.directory);
  await fs.mkdir(directory, { recursive: true });

  const rotated: string[] = [];
  const removed: string[] = [];
  const activeLogFile = input.activeLogFile ? path.resolve(input.activeLogFile) : undefined;

  if (activeLogFile && (await pathExists(activeLogFile))) {
    const activeStat = await fs.stat(activeLogFile);
    if (activeStat.size > input.maxBytes) {
      const rotatedName = `${path.basename(activeLogFile, path.extname(activeLogFile))}-${Date.now()}${path.extname(activeLogFile)}`;
      const rotatedPath = path.join(path.dirname(activeLogFile), rotatedName);
      await fs.rename(activeLogFile, rotatedPath);
      await fs.writeFile(activeLogFile, "", "utf8");
      rotated.push(rotatedPath);
    }
  }

  const entries = await fs.readdir(directory, { withFileTypes: true });
  const files = await Promise.all(
    entries
      .filter((entry) => entry.isFile())
      .map(async (entry) => {
        const filePath = path.join(directory, entry.name);
        const stat = await fs.stat(filePath);
        return { filePath, mtimeMs: stat.mtimeMs };
      })
  );

  files.sort((a, b) => b.mtimeMs - a.mtimeMs);
  for (const stale of files.slice(input.maxFiles)) {
    await fs.rm(stale.filePath, { force: true });
    removed.push(stale.filePath);
  }

  return {
    directory,
    rotated,
    removed
  };
}
