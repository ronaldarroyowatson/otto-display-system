export function executeFileCommand(commandName: string, input?: Record<string, unknown>): Promise<any>;
