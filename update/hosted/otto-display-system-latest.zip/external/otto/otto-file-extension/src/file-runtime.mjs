import fs from "node:fs/promises";
import path from "node:path";

const DEFAULT_REGISTRY_PATH = path.join("manifests", "install-registry.json");

function registryPath() {
  return path.join(process.cwd(), DEFAULT_REGISTRY_PATH);
}

async function pathExists(targetPath) {
  try {
    await fs.access(targetPath);
    return true;
  } catch {
    return false;
  }
}

async function readInstallRegistry() {
  const filePath = registryPath();
  if (!(await pathExists(filePath))) {
    return [];
  }

  const content = await fs.readFile(filePath, "utf8");
  const parsed = JSON.parse(content);
  return Array.isArray(parsed) ? parsed : [];
}

function assertSafeTarget(targetPath) {
  const resolved = path.resolve(targetPath);
  const parsed = path.parse(resolved);
  if (resolved === parsed.root) {
    throw new Error(`Refusing to operate on filesystem root: ${resolved}`);
  }
}

async function checkSpace(input) {
  const stats = await fs.statfs(path.resolve(input.targetPath));
  const availableBytes = Number(stats.bavail) * Number(stats.bsize);
  return {
    ok: availableBytes >= input.minBytes,
    targetPath: path.resolve(input.targetPath),
    minBytes: input.minBytes,
    availableBytes
  };
}

async function listInstalls() {
  const installs = await readInstallRegistry();
  return {
    registryPath: registryPath(),
    installs: installs.sort((a, b) => String(b.updatedAt).localeCompare(String(a.updatedAt)))
  };
}

async function getInstallInfo(input) {
  const installs = await readInstallRegistry();
  return installs.find((entry) => entry.id === input.id) ?? null;
}

async function deletePath(input) {
  assertSafeTarget(input.targetPath);
  const deletedPath = path.resolve(input.targetPath);
  await fs.rm(deletedPath, { recursive: input.recursive ?? true, force: input.force ?? false });
  return { ok: true, deletedPath };
}

async function rotateLogs(input) {
  const directory = path.resolve(input.directory);
  await fs.mkdir(directory, { recursive: true });

  const rotated = [];
  const removed = [];
  const activeLogFile = input.activeLogFile ? path.resolve(input.activeLogFile) : undefined;

  if (activeLogFile && (await pathExists(activeLogFile))) {
    const activeStat = await fs.stat(activeLogFile);
    if (activeStat.size > input.maxBytes) {
      const rotatedName = `${path.basename(activeLogFile, path.extname(activeLogFile))}-${Date.now()}${path.extname(activeLogFile)}`;
      const rotatedPath = path.join(path.dirname(activeLogFile), rotatedName);
      await fs.rename(activeLogFile, rotatedPath);
      await fs.writeFile(activeLogFile, "", "utf8");
      rotated.push(rotatedPath);
    }
  }

  const entries = await fs.readdir(directory, { withFileTypes: true });
  const files = await Promise.all(
    entries
      .filter((entry) => entry.isFile())
      .map(async (entry) => {
        const filePath = path.join(directory, entry.name);
        const stat = await fs.stat(filePath);
        return { filePath, mtimeMs: stat.mtimeMs };
      })
  );

  files.sort((a, b) => b.mtimeMs - a.mtimeMs);
  for (const stale of files.slice(input.maxFiles)) {
    await fs.rm(stale.filePath, { force: true });
    removed.push(stale.filePath);
  }

  return { directory, rotated, removed };
}

export async function executeFileCommand(commandName, input = {}) {
  switch (commandName) {
    case "file.check.space":
      return checkSpace(input);
    case "file.list.installs":
      return listInstalls();
    case "file.get.install.info":
      return getInstallInfo(input);
    case "file.delete.path":
      return deletePath(input);
    case "file.rotate.logs":
      return rotateLogs(input);
    default:
      throw new Error(`Unknown file command: ${commandName}`);
  }
}
