import assert from "node:assert/strict";
import { mkdtemp, mkdir, readFile, rm, writeFile } from "node:fs/promises";
import os from "node:os";
import path from "node:path";
import test from "node:test";

test("file.check.space returns expected shape", async () => {
  const { executeFileCommand } = await import("../src/file-runtime.mjs");
  const result = await executeFileCommand("file.check.space", {
    targetPath: ".",
    minBytes: 1
  });

  assert.equal(typeof result.ok, "boolean");
  assert.equal(result.ok, true);
  assert.equal(typeof result.availableBytes, "number");
  assert.equal(result.minBytes, 1);
});

test("file.get.install.info and file.list.installs read install registry", async () => {
  const { executeFileCommand } = await import("../src/file-runtime.mjs");
  const tempRoot = await mkdtemp(path.join(os.tmpdir(), "otto-file-registry-"));
  const previousCwd = process.cwd();

  try {
    process.chdir(tempRoot);
    await mkdir(path.join(tempRoot, "manifests"), { recursive: true });
    await writeFile(
      path.join(tempRoot, "manifests", "install-registry.json"),
      JSON.stringify(
        [
          {
            id: "display-system",
            installPath: "/opt/otto-display-system/current",
            version: "1.2.3",
            sizeBytes: 12345,
            updatedAt: "2026-08-19T00:00:00.000Z"
          }
        ],
        null,
        2
      ),
      "utf8"
    );

    const listed = await executeFileCommand("file.list.installs", {});
    assert.equal(listed.installs.length, 1);
    assert.equal(listed.installs[0].id, "display-system");

    const info = await executeFileCommand("file.get.install.info", { id: "display-system" });
    assert.equal(info?.version, "1.2.3");
  } finally {
    process.chdir(previousCwd);
    await rm(tempRoot, { recursive: true, force: true });
  }
});

test("file.rotate.logs prunes stale log files", async () => {
  const { executeFileCommand } = await import("../src/file-runtime.mjs");
  const tempRoot = await mkdtemp(path.join(os.tmpdir(), "otto-file-logs-"));

  try {
    const logsDir = path.join(tempRoot, "logs");
    await mkdir(logsDir, { recursive: true });
    await writeFile(path.join(logsDir, "a.log"), "a", "utf8");
    await writeFile(path.join(logsDir, "b.log"), "b", "utf8");
    await writeFile(path.join(logsDir, "c.log"), "c", "utf8");

    const result = await executeFileCommand("file.rotate.logs", {
      directory: logsDir,
      maxFiles: 2,
      maxBytes: 100000
    });

    assert.equal(result.directory, path.resolve(logsDir));
    assert.equal(Array.isArray(result.removed), true);
    assert.equal(result.removed.length, 1);
  } finally {
    await rm(tempRoot, { recursive: true, force: true });
  }
});

test("file.delete.path removes managed path", async () => {
  const { executeFileCommand } = await import("../src/file-runtime.mjs");
  const tempRoot = await mkdtemp(path.join(os.tmpdir(), "otto-file-delete-"));

  try {
    const targetFile = path.join(tempRoot, "payload", "delete-me.log");
    await mkdir(path.dirname(targetFile), { recursive: true });
    await writeFile(targetFile, "temp", "utf8");

    const deleted = await executeFileCommand("file.delete.path", {
      targetPath: targetFile,
      recursive: false,
      force: false
    });

    assert.equal(deleted.ok, true);
    const stillThere = await readFile(targetFile, "utf8").then(() => true).catch(() => false);
    assert.equal(stillThere, false);
  } finally {
    await rm(tempRoot, { recursive: true, force: true });
  }
});
